Much love to my patrons, who helped make this asset pack possible!

Henry 
Hussain manaf
Peter 
Kuma Kreation
Sergio CM
Harvey Redfield
conan_edw 
KC
MD Cyberbat.
Kadie Elizabeth Alexander
Christa Sparks
Jonny Ashley
Joe Kallman
Cameron Calka
Neurisko
Psyloh Dubs
Frankie Bays
Haldarc
Bokuman  Studio
Thomas Webb
Nacho Frades
Lord Humungus
Charles Tangora
Siluman 
Zack 
Jesse Day
Josh Bossie
Abby K
Kyle Cespedes
nemuruibai 
Raimonds Iodzevics
nick lenn
Hannah Lise
DayExMok 
Liyi Zhang
Mara Vertin
Krzysztof Wende
Reakain 
Sebastian Paul
Jahan 
Pigeon Hat
Deanishes 
Hyperlink Your Heart
Dave
cheezopath 
OD_Garfield 
Stefanie Grunwald (@moertel)
MaFrä 
c-m 
Cthulhumishka (Ктулхумишка)
Michelle Milburn
Nicole Martini
Jonathan Holt
Broos Nemanic